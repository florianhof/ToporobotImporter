#!/usr/bin/perl -w --

# by Florian Hof <florian@speleo.ch> 
# created: 08.08.2005 
# modified: 02.09.2010 


# usage: 
# merge.pl -c Codes.Text -o Out.Text -i Out.txt -d Out.dbf In1.Text In2.Text ... 


# read arguments

local @inFilePaths; # In1.Text In2.Text ...
local $inFileCodes; # -c Codes.Text
local $outTextFilePath; # -o Out.Text 
local $outInfoFilePath; # -i Out.txt 
local $outDataFilePath; # -d Out.(dbf|csv|*) 
local $outDataSep; # -d, or -d; or -d| or -dv or -dt or -dn 


local $fieldnameType = 'TYPE';
local $fieldnameNumNew = 'SERIE_NR_MERGED';
local $fieldnameNumOld = 'SERIE_NR_ORIGINAL';
#local $fieldnameName = 'SERIE_NAME';
local $fieldnameFile = 'FILE_NAME';


my $nbArgErrors = 0;
my $minArgIndex = 0;
my $maxArgIndex = $#ARGV;
my $isOptions = 1;
for (my $argIndex = $minArgIndex ; $argIndex <= $maxArgIndex ; $argIndex++) {
  if ($isOptions and substr($ARGV[$argIndex],0,1) eq "-") {
    if ($ARGV[$argIndex] eq "-c") {
      $argIndex++;
      if ($ARGV[$argIndex] eq "--") {
        $isOptions = 0;
        $inFileCodes = "";
      } else {
        $inFileCodes = $ARGV[$argIndex];
      }
    } 
    elsif ($ARGV[$argIndex] eq "-o") {
      $argIndex++;
      $outTextFilePath = $ARGV[$argIndex];
    } 
    elsif ($ARGV[$argIndex] eq "-i") {
      $argIndex++;
      $outInfoFilePath = $ARGV[$argIndex];
    } 
    elsif ($ARGV[$argIndex] eq "-d") {
      $argIndex++;
      $outDataFilePath = $ARGV[$argIndex];
    } 
    elsif ($ARGV[$argIndex] eq "-d,") {
      $outDataSep = ",";
      $argIndex++;
      $outDataFilePath = $ARGV[$argIndex];
    } 
    elsif ($ARGV[$argIndex] eq "-d;") {
      $outDataSep = ";";
      $argIndex++;
      $outDataFilePath = $ARGV[$argIndex];
    } 
    elsif ($ARGV[$argIndex] eq "-d|") {
      $outDataSep = "|";
      $argIndex++;
      $outDataFilePath = $ARGV[$argIndex];
    } 
    elsif ($ARGV[$argIndex] eq "-dv") {
      $outDataSep = "|";
      $argIndex++;
      $outDataFilePath = $ARGV[$argIndex];
    } 
    elsif ($ARGV[$argIndex] eq "-dt") {
      $outDataSep = "\t";
      $argIndex++;
      $outDataFilePath = $ARGV[$argIndex];
    } 
    elsif ($ARGV[$argIndex] eq "-dn") {
      $outDataSep = "\n";
      $argIndex++;
      $outDataFilePath = $ARGV[$argIndex];
    } 
    elsif ($ARGV[$argIndex] eq "--") {
      $isOptions = 0;
    } 
    else {
      $nbArgErrors++;
      print STDERR "error: unknown option '$ARGV[$argIndex]'\n";
    } 
  }
  else {
    push @inFilePaths, $ARGV[$argIndex];
  }
}
exit 1 if $nbArgErrors;


# prepare output

my @outEntriesName = ();
my @outEntriesCoord = ();
my @outMiscs = ();
my @outExplos = ();
my @outCodes = ();
my %outCodes = (); # codes per definition
my %commonCodes = ();
my $outSeriesNb = 0;
my @outStations = ();
my $outDataFile;

BEGIN {
    # access libraries in script's folder
    my $scriptFolder = __FILE__; $scriptFolder =~ s#((.*/)?)(.*)#$1#;
    push @INC, $scriptFolder;
}
  
if (defined $outTextFilePath) {
    open(STDOUT, ">", $outTextFilePath) 
        or die "error: cannot write into file $outTextFilePath, stopped";
}
if (defined $outInfoFilePath) {
    open(OutInfoFile, ">", $outInfoFilePath) 
        or die "error: cannot write into file $outInfoFilePath, stopped";
	print OutInfoFile "Starting at ".(scalar localtime())."\n";
}
if (defined $outDataFilePath) {
    if (defined $outDataSep) { # comma or tab separated values 
        open(OutDataFile, ">", $outDataFilePath) 
            or die "error: cannot write into file $outDataFilePath, stopped";
        print OutDataFile "${fieldnameType}${outDataSep}";
        print OutDataFile "${fieldnameNumNew}${outDataSep}";
        print OutDataFile "${fieldnameNumOld}${outDataSep}";
        #print OutDataFile "${fieldnameName}${outDataSep}";
        print OutDataFile "${fieldnameFile}\n";
    } else { # DBF 
        use CAM::DBF;
        $outDataFile = CAM::DBF->create($outDataFilePath,
            {name=>$fieldnameType,   type=>"N", length=>  2, decimals=>0},
            {name=>$fieldnameNumNew, type=>"N", length=>  6, decimals=>0},
            {name=>$fieldnameNumOld, type=>"N", length=>  6, decimals=>0},
            #{name=>$fieldnameName,   type=>"C", length=> 80, decimals=>0},
            {name=>$fieldnameFile,   type=>"C", length=>255, decimals=>0},
        ) or die "error: cannot write into file $outDataFilePath, stopped";
    }
}

sub mydebug {
    my $msg = $_[0];
    return 1; # to deactivate debug
    if (defined $outInfoFilePath) { 
        print OutInfoFile $msg."\n";} 
    else {
        print STDERR $msg."\n";}
}
my $warnNb = 0;
sub mywarn {
    my $msg = $_[0];
    $warnNb ++;
    if (defined $outInfoFilePath) { 
        print OutInfoFile '! '.$msg."\n";} 
    else {
        print STDERR '! '.$msg."\n";}
}
$SIG{__WARN__} = sub
{
    #my @loc = caller(1);
    #print STDOUT "Warning at line $loc[2] in $loc[1]:", @_, "\n";
    mywarn join($, || '' , @_) . ($\ || '');
    return 1;
};

sub writeOutDataFile {
    ($type, $outNb, $inNb, $filename) = @_;
    if (defined $outDataFilePath) {
        if (defined $outDataSep) { # comma or tab separated values 
            print OutDataFile "$type${outDataSep}";
            print OutDataFile "${outNb}${outDataSep}";
            print OutDataFile "${inNb}${outDataSep}";
            print OutDataFile "\"${filename}\"\n";
        } else { # DBF 
            $outDataFile->appendrow_hashref({
                $fieldnameType   => $type,
                $fieldnameNumNew => $outNb,
                $fieldnameNumOld => $inNb,
                $fieldnameFile   => $filename
            });
        }
    }
}

# process code file

if (defined $inFileCodes && $inFileCodes ne '') {
    mydebug("processing code file $inFileCodes");
    my $inFileName = $inFileCodes; $inFileName =~ s|(.*/)?(.*)|$2|;
    my $maxCodeNb = 0; 

    open InCodes, $inFileCodes;
    my $lineNb = 0;
    while (defined (my $lines = <InCodes>)) {
      my @lines = split /\x0D|\x0A/, $lines; # split on any end of line
      LineProcessing: foreach my $line (@lines) {
        $lineNb ++;
    	mydebug("processing $lineNb. line $line");
        $line = $line . "\x0D"; # officially ends with a Mac end of line
        if ($line =~ /^(\s|\x0D|\x0A)*$/) { # if empty or only withspace(s) 
	        mydebug("$lineNb. line is empty ");
        } elsif (length($line) < 13) { # too short for a normal line
	        mywarn("cannot extract serie and station nb, line $lineNb is too short; current line is '$line'");
	        next;
        }
        my $inLinePrefix;
        my $inSerieNb;
        my $inStationNb; 
		$inLinePrefix = substr $line, 0, 1; 
		$inSerieNb = substr $line, 1, 5; 
		if ($inSerieNb !~ / *\d+ */) {
        	mywarn("cannot extract serie number, not a number; current line $lineNb is '$line'");
        	next;
		}
        $inSerieNb = $inSerieNb + 0; # as a number
        $inStationNb = substr $line, 7, 5;
        if ($inStationNb !~ / *\d+ */) {
        	mywarn("cannot extract code number, not a number; current line $lineNb is '$line'");
        	next;
        }
        $inStationNb = $inStationNb + 0; # as a number
        mydebug("processing code $inStationNb of serie $inSerieNb from line $lineNb");

        if ($inLinePrefix ne ' ') { # special line; a normal line begins with a space
        	next; # ignore

        } elsif ($inSerieNb == -1) { # codes
        	$commonCodes{$inStationNb} = $line;
        	$outCodes{substr $line, 12} = $inStationNb;
	        push @outCodes, $line; 
	        writeOutDataFile(-1, $inStationNb, $inStationNb, $inFileName);
        	$maxCodeNb = $inStationNb if ($inStationNb > $maxCodeNb);
        } # end of code processing
    }  } # end of line processing
    close InCodes;
    
    #foreach my $key (sort {$a <=> $b} keys %commonCodes) {
    #    push @outCodes, $commonCodes{$key}; 
    #    writeOutDataFile(-1, $key, $key, $inFileName);
    #}
    for (my $i = (scalar @outCodes) ; $i < $maxCodeNb ; $i++) {
        push @outCodes, ''; # so that scalar @outCodes == $maxCodeNb
    } 
}

# process each file

my $inFileNb = 0;
FileProcessing: foreach my $inFilePath (@inFilePaths) {
    $inFileNb ++;
    mydebug("processing $inFileNb. file $inFilePath");
    my $inFileName = $inFilePath; $inFileName =~ s|(.*/)?(.*)|$2|;
    my %mapExplos = ();
    my %mapCodes = ();
    my %mapSeries = (); $mapSeries{0} = 0;
    my $outStationsNb = scalar @outStations;
    my $outEntriesNb = scalar @outEntriesCoord;
    
    my $msg = sprintf "From serie %5d, file %s\n", ($outSeriesNb + 1), $inFileName;
    if (defined $outInfoFilePath) { 
        print OutInfoFile $msg;} 
    else {
        print STDERR $msg;}

    # process each line
    
    open InFile, $inFilePath;
    my $lineNb = 0;
    while (defined (my $lines = <InFile>)) {
      chomp($lines);
      my @lines = split /\x0D|\x0A/, $lines; # split on any end of line
      LineProcessing: foreach my $line (@lines) {
        $lineNb ++;
    	mydebug("processing $lineNb. line $line");
        $line = $line . "\x0D"; # officially ends with a Mac end of line
        if ($line =~ /^(\s|\x0D|\x0A)*$/) { # if empty or only withspace(s) 
	        mydebug("$lineNb. line is empty ");
		    next; # ignore silently
        #} elsif ((substr $line, 0, 1) ne ' ') { # special line; a normal line begins with a space
	    #    mydebug("$lineNb. line is special ");
	    #    next; # ignore silently
        } elsif (length($line) < 13) { # too short for a normal line
	        mywarn("cannot extract serie and station nb, line $lineNb is too short; current line is '$line'");
	        next;
        }
        my $inLinePrefix;
        my $inSerieNb;
        my $inStationNb; 
		$inLinePrefix = substr $line, 0, 1; 
		$inSerieNb = substr $line, 1, 5; 
		if ($inSerieNb !~ / *\d+ */) {
        	mywarn("cannot extract serie number, not a number; current line $lineNb is '$line'");
        	next;
		}
        $inSerieNb = $inSerieNb + 0; # as a number
        $inStationNb = substr $line, 7, 5;
        if ($inStationNb !~ / *\d+ */) {
        	mywarn("cannot extract station number, not a number; current line $lineNb is '$line'");
        	next;
        }
        $inStationNb = $inStationNb + 0; # as a number
        mydebug("processing station $inStationNb of serie $inSerieNb from line $lineNb");

        # handle "special" line (comment, etc)
        
        if ($inLinePrefix ne ' ') { # special line; a normal line begins with a space

	        if ($inLinePrefix eq '(') {
	        	mydebug("line $lineNb is a comment");
	        } else {
	        	mywarn("unknown line start '$inLinePrefix' at line $lineNb");
	        }

        # handle "special" series (explo, codes, etc)
        
        } elsif ($inSerieNb == -6) { # entries' name 
            substr $line, 7, 5, (sprintf '%5d', (@outEntriesName + 1));
            push @outEntriesName, $line;
            writeOutDataFile($inSerieNb, scalar @outEntriesName, $inStationNb, $inFileName);
        } elsif ($inSerieNb == -5) { # entries' coordinates
            substr $line, 7, 5, (sprintf '%5d', (@outEntriesCoord + 1));
            push @outEntriesCoord, $line;
        } elsif ($inSerieNb == -4 or $inSerieNb == -3) { # some blabla
            push @outMiscs, $line if ($inFileNb == 1);
            writeOutDataFile($inSerieNb, scalar @outMiscs, $inStationNb, $inFileName);
        } elsif ($inSerieNb == -2) { # explos
            $mapExplos{$inStationNb} = (@outExplos + 1);
	        mydebug("explo $inStationNb added as explo $mapExplos{$inStationNb}");
            substr $line, 7, 5, (sprintf '%5d', (scalar @outExplos) + 1);
            push @outExplos, $line;
            writeOutDataFile($inSerieNb, scalar @outExplos, $inStationNb, $inFileName);
        } elsif ($inSerieNb == -1) { # codes
            if (defined $outCodes{substr $line, 12}) {
                $mapCodes{$inStationNb} = $outCodes{substr $line, 12};
            } else {
        	    my $outStationNb = (scalar @outCodes) + 1;
                $mapCodes{$inStationNb} = $outStationNb;
        	    $outCodes{substr $line, 12} = $outStationNb;
                substr $line, 7, 5, (sprintf '%5d', $outStationNb);
	            push @outCodes, $line; 
	            writeOutDataFile(-1, $outStationNb, $inStationNb, $inFileName);
            }
             
        # handle "normal" series (galeries)
        
        } elsif ($inSerieNb > 0) {
            if ($inStationNb == -2) { # series definition 
                $outSeriesNb ++;
                $mapSeries{$inSerieNb} = $outSeriesNb;
                writeOutDataFile('1', $outSeriesNb, $inSerieNb, $inFileName);
            }
            substr $line, 1, 5, (sprintf '%5d', $outSeriesNb);
            if ($inStationNb >= 0) { # stations 
                my $inExploNb = (substr $line, 20, 4) + 0;
                substr $line, 20, 4, (sprintf '%4d', $mapExplos{$inExploNb});
                my $inCodeNb = (substr $line, 12, 4) + 0;
                substr $line, 12, 4, (sprintf '%4d', $mapCodes{$inCodeNb});
             }
            push @outStations, ($line);
        } # end of station processing
    }  } # end of line processing
    close InFile;
    
    # some more special stuff for series link (junctions and entries)
    
    foreach my $i ($outStationsNb..$#outStations) {
        my $line = $outStations[$i];
        my $inStationNb = (substr $line, 7, 5) + 0;
        if ($inStationNb == -1) {
            my $inSerieNb;
            $inSerieNb = (substr $line, 25, 7) + 0;
            substr $line, 25, 7, (sprintf '%7d', $mapSeries{$inSerieNb});
            $inSerieNb = (substr $line, 41, 7) + 0;
            substr $line, 41, 7, (sprintf '%7d', $mapSeries{$inSerieNb});
        }
        $outStations[$i] = $line;
    }
    foreach my $i ($outEntriesNb..$#outEntriesCoord) {
        my $line = $outEntriesCoord[$i];
        my $inSerieNb = (substr $line, 61, 5) + 0;
        substr $line, 61, 5, (sprintf '%5d', $mapSeries{$inSerieNb});
        $outEntriesCoord[$i] = $line;
    }
    
}

# write output

print @outEntriesName;
print @outEntriesCoord;
print @outMiscs;
print @outExplos;
foreach $outCode (@outCodes) {
	print $outCode if $outCode;
}
print @outStations;

my $msg = sprintf "Processed %d file%s, written %d entrie%s, %d explo%s, %d code%s, %d serie%s and %d stations%s.\n", 
                     scalar @inFilePaths, (@inFilePaths > 1) ? 's' : '', 
                     scalar @outEntriesName, (@outEntriesName > 1) ? 's' : '', 
                     scalar @outExplos, (@outExplos > 1) ? 's' : '', 
                     scalar @outCodes, (@outCodes > 1) ? 's' : '', 
                     scalar $outSeriesNb, ($outSeriesNb > 1) ? 's' : '', 
                     scalar @outStations - 2 * $outSeriesNb,
                     ($warnNb > 0) ? " with $warnNb problems! Some data will be missing" : '';
print OutInfoFile $msg if (defined $outInfoFilePath);
print STDERR $msg; # the most important to report
if (defined $outInfoFilePath) { 
	print OutInfoFile "Finished at ".(scalar localtime())."\n";}

close(OutInfoFile) if (defined $outInfoFilePath);
if (defined $outDataSep) {
    close(OutDataFile) if (defined $outDataFilePath);
} else {
    $outDataFile->closeDB if (defined $outDataFilePath);
}

exit;
__END__
