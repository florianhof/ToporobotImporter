#!/usr/bin/perl -w --
use strict;

# read arguments
my @inFilePaths = @ARGV;

# prepare processing
my $scriptFolder = __FILE__; $scriptFolder =~ s#(.*/)?(.*)#$1#;
my $inErrorsNb = 0;
my %correctCodes = &getCodes($scriptFolder.'Codes.Text');
my %outCodes = ();

# process each file
my $inFileNb = 0;
FileProcessing: foreach my $inFilePath (@inFilePaths) {
  $inFileNb ++;
  my $inFileName = $inFilePath; $inFileName =~ s#.*/(.*)#$1#;
  my $inSerieLastNb = -7;
  my %inCodes = ();

  # check file name 
  if ($inFileName !~ /.Text$/) {
    &setError($inFileName, "file name does not end with '.Text'.");
  }
  
  # process each line
  open InFile, $inFilePath;
  while (defined (my $ligns = <InFile>)) {
    my @ligns = split /\r/, $ligns;

    # check start of file
    if ((substr $ligns[0], 0, 12) ne '    -6     1') {
      &setError($inFileName, "does not start like Toporobot files, skipped.");
      next FileProcessing;
    }

    LignProcessing: foreach my $lign (@ligns) {
      $lign = $lign . "\r";
      my $inSerieNb = (substr $lign, 1, 5) + 0;
      my $inStationNb = (substr $lign, 7, 5) + 0;
      if ($lign eq '') {
      } elsif ((substr $lign, 0, 1) ne ' ') {
      } else {

	# check continuity of special (negative) 'series' 
	if ($inSerieNb < $inSerieLastNb) {
	  &setError($inFileName, "serie $inSerieNb is after serie $inSerieLastNb.");
	} elsif (($inSerieNb < 0) && ($inSerieNb > $inSerieLastNb + 1)) {
	  &setError($inFileName, "missing special 'serie' ".($inSerieLastNb+1).".");
	} elsif (($inSerieNb > 1) && ($inSerieLastNb == -1)) {
	  &setError($inFileName, "missing initial serie 1.");
	}
	$inSerieLastNb = $inSerieNb;

	# check explos
	if ($inSerieNb == -2) {
	  if (length $lign <= 24+1) {
            &setError($inFileName, "explo ".$inStationNb." has no data (date / topographs).");
	  } else {
  	    my $exploDate = substr $lign, 25, 8;
	    my $exploDay = substr $lign, 25, 2;
            my $exploMonth = substr $lign, 28, 2;
            my $exploYear = substr $lign, 31, 2;
            if ($exploDay < 1 || $exploDay > 31 ||
                $exploMonth < 1 || $exploMonth > 12 ||
                $exploYear < 0 || $exploYear > 99 ||
                $exploYear > 20 && $exploYear < 70 ) {
              &setError($inFileName, "date ".$exploDate." of explo ".$inStationNb." is perhaps invalid.");
            }
            if (length $lign <= 63+1) {
              #&setError($inFileName, "explo ".$inStationNb." has no auto-declin. data.");
            } elsif ((substr $lign, 63, 1) ne '1' && $inStationNb != 999) {
              #&setError($inFileName, "explo ".$inStationNb." has auto-declin not set.");
            }
            if (length $lign <= 72+1) {
              if (length $lign > 63+1) {
                #&setError($inFileName, "explo ".$inStationNb." has no color.");
              }
            } else {
              my $exploColor = (substr $lign, 76, 4) + 0;
              if ($exploColor != 1) {
                &setError($inFileName, "explo ".$inStationNb." has color ".$exploColor.".");
              }
            }
          }

	# check codes compared to a model
	} elsif ($inSerieNb == -1) {
	  if (exists $inCodes{$inStationNb}) {
	    &setError($inFileName, "code $inStationNb already defined.");
	  } elsif (!exists $correctCodes{$inStationNb}) {
	    &setError($inFileName, "code $inStationNb is new.");
	  } elsif ($lign ne $correctCodes{$inStationNb}) {
	    &setError($inFileName, "code $inStationNb differs from model.");
	  }
	  $inCodes{$inStationNb} = $lign;
	  
	# check useless entries
	} elsif ($inSerieNb == -5) {
	  if ((substr $lign, 61, 5) == 0) {
	    &setError($inFileName, "entry $inStationNb is useless on serie 0.");
	  }

	}
      }
  } }
  close InFile;
    
}

sub setError {
  my ($filename, $message) = @_;
  print "File '$filename', $message\n";
  ++$inErrorsNb;
}

# load codes from a file, given a filepath
sub getCodes {
  my ($filepath) = @_;
  my %codes = ();
  open InFile, $filepath;
  while (defined (my $ligns = <InFile>)) {
    my @ligns = split /\r/, $ligns;
    foreach my $lign (@ligns) {
      $lign = $lign . "\r";
      my $inSerieNb = (substr $lign, 1, 5) + 0;
      my $inStationNb = (substr $lign, 7, 5) + 0;
      if ($lign eq '') {
      } elsif ((substr $lign, 0, 1) ne ' ') {
        
      # load codes
      } elsif ($inSerieNb == -1) {
        $codes{$inStationNb} = $lign;

      }
  } }
  close InFile;
  return %codes;
}
print STDERR sprintf "Processed %d file%s, found %d warnings/problems.\n", 
                     scalar @inFilePaths, (@inFilePaths > 1) ? 's' : '', 
                     $inErrorsNb;
exit $inErrorsNb;
__END__

